/**
 * Fuse.js v6.6.2 - Lightweight fuzzy-search (http://fusejs.io)
 *
 * Copyright (c) 2022 Kiro Risk (http://kiro.me)
 * All Rights Reserved. Apache Software License 2.0
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 */
var e, t;
(e = this),
  (t = function () {
    "use strict";
    function e(e, t) {
      var n = Object.keys(e);
      if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(e);
        t &&
          (r = r.filter(function (t) {
            return Object.getOwnPropertyDescriptor(e, t).enumerable;
          })),
          n.push.apply(n, r);
      }
      return n;
    }
    function t(t) {
      for (var n = 1; n < arguments.length; n++) {
        var r = null != arguments[n] ? arguments[n] : {};
        n % 2
          ? e(Object(r), !0).forEach(function (e) {
              c(t, e, r[e]);
            })
          : Object.getOwnPropertyDescriptors
          ? Object.defineProperties(t, Object.getOwnPropertyDescriptors(r))
          : e(Object(r)).forEach(function (e) {
              Object.defineProperty(
                t,
                e,
                Object.getOwnPropertyDescriptor(r, e)
              );
            });
      }
      return t;
    }
    function n(e) {
      return (
        (n =
          "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
            ? function (e) {
                return typeof e;
              }
            : function (e) {
                return e &&
                  "function" == typeof Symbol &&
                  e.constructor === Symbol &&
                  e !== Symbol.prototype
                  ? "symbol"
                  : typeof e;
              }),
        n(e)
      );
    }
    function r(e, t) {
      if (!(e instanceof t))
        throw new TypeError("Cannot call a class as a function");
    }
    function i(e, t) {
      for (var n = 0; n < t.length; n++) {
        var r = t[n];
        (r.enumerable = r.enumerable || !1),
          (r.configurable = !0),
          "value" in r && (r.writable = !0),
          Object.defineProperty(e, r.key, r);
      }
    }
    function o(e, t, n) {
      return (
        t && i(e.prototype, t),
        n && i(e, n),
        Object.defineProperty(e, "prototype", { writable: !1 }),
        e
      );
    }
    function c(e, t, n) {
      return (
        t in e
          ? Object.defineProperty(e, t, {
              value: n,
              enumerable: !0,
              configurable: !0,
              writable: !0,
            })
          : (e[t] = n),
        e
      );
    }
    function a(e, t) {
      if ("function" != typeof t && null !== t)
        throw new TypeError(
          "Super expression must either be null or a function"
        );
      Object.defineProperty(e, "prototype", {
        value: Object.create(t && t.prototype, {
          constructor: { value: e, writable: !0, configurable: !0 },
        }),
        writable: !1,
      }),
        t && u(e, t);
    }
    function s(e) {
      return (
        (s = Object.setPrototypeOf
          ? Object.getPrototypeOf
          : function (e) {
              return e.__proto__ || Object.getPrototypeOf(e);
            }),
        s(e)
      );
    }
    function u(e, t) {
      return (
        (u =
          Object.setPrototypeOf ||
          function (e, t) {
            return (e.__proto__ = t), e;
          }),
        u(e, t)
      );
    }
    function h(e, t) {
      if (t && ("object" == typeof t || "function" == typeof t)) return t;
      if (void 0 !== t)
        throw new TypeError(
          "Derived constructors may only return object or undefined"
        );
      return (function (e) {
        if (void 0 === e)
          throw new ReferenceError(
            "this hasn't been initialised - super() hasn't been called"
          );
        return e;
      })(e);
    }
    function l(e) {
      var t = (function () {
        if ("undefined" == typeof Reflect || !Reflect.construct) return !1;
        if (Reflect.construct.sham) return !1;
        if ("function" == typeof Proxy) return !0;
        try {
          return (
            Boolean.prototype.valueOf.call(
              Reflect.construct(Boolean, [], function () {})
            ),
            !0
          );
        } catch (e) {
          return !1;
        }
      })();
      return function () {
        var n,
          r = s(e);
        if (t) {
          var i = s(this).constructor;
          n = Reflect.construct(r, arguments, i);
        } else n = r.apply(this, arguments);
        return h(this, n);
      };
    }
    function f(e) {
      return (
        (function (e) {
          if (Array.isArray(e)) return d(e);
        })(e) ||
        (function (e) {
          if (
            ("undefined" != typeof Symbol && null != e[Symbol.iterator]) ||
            null != e["@@iterator"]
          )
            return Array.from(e);
        })(e) ||
        (function (e, t) {
          if (e) {
            if ("string" == typeof e) return d(e, t);
            var n = Object.prototype.toString.call(e).slice(8, -1);
            return (
              "Object" === n && e.constructor && (n = e.constructor.name),
              "Map" === n || "Set" === n
                ? Array.from(e)
                : "Arguments" === n ||
                  /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)
                ? d(e, t)
                : void 0
            );
          }
        })(e) ||
        (function () {
          throw new TypeError(
            "Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."
          );
        })()
      );
    }
    function d(e, t) {
      (null == t || t > e.length) && (t = e.length);
      for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
      return r;
    }
    function v(e) {
      return Array.isArray ? Array.isArray(e) : "[object Array]" === b(e);
    }
    function g(e) {
      return "string" == typeof e;
    }
    function y(e) {
      return "number" == typeof e;
    }
    function p(e) {
      return (
        !0 === e ||
        !1 === e ||
        ((function (e) {
          return m(e) && null !== e;
        })(e) &&
          "[object Boolean]" == b(e))
      );
    }
    function m(e) {
      return "object" === n(e);
    }
    function k(e) {
      return null != e;
    }
    function M(e) {
      return !e.trim().length;
    }
    function b(e) {
      return null == e
        ? void 0 === e
          ? "[object Undefined]"
          : "[object Null]"
        : Object.prototype.toString.call(e);
    }
    var x = function (e) {
        return "Invalid value for key ".concat(e);
      },
      w = function (e) {
        return "Pattern length exceeds max of ".concat(e, ".");
      },
      L = Object.prototype.hasOwnProperty,
      S = (function () {
        function e(t) {
          var n = this;
          r(this, e), (this._keys = []), (this._keyMap = {});
          var i = 0;
          t.forEach(function (e) {
            var t = _(e);
            (i += t.weight),
              n._keys.push(t),
              (n._keyMap[t.id] = t),
              (i += t.weight);
          }),
            this._keys.forEach(function (e) {
              e.weight /= i;
            });
        }
        return (
          o(e, [
            {
              key: "get",
              value: function (e) {
                return this._keyMap[e];
              },
            },
            {
              key: "keys",
              value: function () {
                return this._keys;
              },
            },
            {
              key: "toJSON",
              value: function () {
                return JSON.stringify(this._keys);
              },
            },
          ]),
          e
        );
      })();
    function _(e) {
      var t = null,
        n = null,
        r = null,
        i = 1,
        o = null;
      if (g(e) || v(e)) (r = e), (t = O(e)), (n = j(e));
      else {
        if (!L.call(e, "name"))
          throw new Error(
            (function (e) {
              return "Missing ".concat(e, " property in key");
            })("name")
          );
        var c = e.name;
        if (((r = c), L.call(e, "weight") && (i = e.weight) <= 0))
          throw new Error(
            (function (e) {
              return "Property 'weight' in key '".concat(
                e,
                "' must be a positive integer"
              );
            })(c)
          );
        (t = O(c)), (n = j(c)), (o = e.getFn);
      }
      return { path: t, id: n, weight: i, src: r, getFn: o };
    }
    function O(e) {
      return v(e) ? e : e.split(".");
    }
    function j(e) {
      return v(e) ? e.join(".") : e;
    }
    var A = {
        useExtendedSearch: !1,
        getFn: function (e, t) {
          var n = [],
            r = !1;
          return (
            (function e(t, i, o) {
              if (k(t))
                if (i[o]) {
                  var c = t[i[o]];
                  if (!k(c)) return;
                  if (o === i.length - 1 && (g(c) || y(c) || p(c)))
                    n.push(
                      (function (e) {
                        return null == e
                          ? ""
                          : (function (e) {
                              if ("string" == typeof e) return e;
                              var t = e + "";
                              return "0" == t && 1 / e == -1 / 0 ? "-0" : t;
                            })(e);
                      })(c)
                    );
                  else if (v(c)) {
                    r = !0;
                    for (var a = 0, s = c.length; a < s; a += 1)
                      e(c[a], i, o + 1);
                  } else i.length && e(c, i, o + 1);
                } else n.push(t);
            })(e, g(t) ? t.split(".") : t, 0),
            r ? n : n[0]
          );
        },
        ignoreLocation: !1,
        ignoreFieldNorm: !1,
        fieldNormWeight: 1,
      },
      I = t(
        t(
          t(
            t(
              {},
              {
                isCaseSensitive: !1,
                includeScore: !1,
                keys: [],
                shouldSort: !0,
                sortFn: function (e, t) {
                  return e.score === t.score
                    ? e.idx < t.idx
                      ? -1
                      : 1
                    : e.score < t.score
                    ? -1
                    : 1;
                },
              }
            ),
            { includeMatches: !1, findAllMatches: !1, minMatchCharLength: 1 }
          ),
          { location: 0, threshold: 0.6, distance: 100 }
        ),
        A
      ),
      C = /[^ ]+/g;
    function E() {
      var e =
          arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : 1,
        t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 3,
        n = new Map(),
        r = Math.pow(10, t);
      return {
        get: function (t) {
          var i = t.match(C).length;
          if (n.has(i)) return n.get(i);
          var o = 1 / Math.pow(i, 0.5 * e),
            c = parseFloat(Math.round(o * r) / r);
          return n.set(i, c), c;
        },
        clear: function () {
          n.clear();
        },
      };
    }
    var $ = (function () {
      function e() {
        var t =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
          n = t.getFn,
          i = void 0 === n ? I.getFn : n,
          o = t.fieldNormWeight,
          c = void 0 === o ? I.fieldNormWeight : o;
        r(this, e),
          (this.norm = E(c, 3)),
          (this.getFn = i),
          (this.isCreated = !1),
          this.setIndexRecords();
      }
      return (
        o(e, [
          {
            key: "setSources",
            value: function () {
              var e =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : [];
              this.docs = e;
            },
          },
          {
            key: "setIndexRecords",
            value: function () {
              var e =
                arguments.length > 0 && void 0 !== arguments[0]
                  ? arguments[0]
                  : [];
              this.records = e;
            },
          },
          {
            key: "setKeys",
            value: function () {
              var e = this,
                t =
                  arguments.length > 0 && void 0 !== arguments[0]
                    ? arguments[0]
                    : [];
              (this.keys = t),
                (this._keysMap = {}),
                t.forEach(function (t, n) {
                  e._keysMap[t.id] = n;
                });
            },
          },
          {
            key: "create",
            value: function () {
              var e = this;
              !this.isCreated &&
                this.docs.length &&
                ((this.isCreated = !0),
                g(this.docs[0])
                  ? this.docs.forEach(function (t, n) {
                      e._addString(t, n);
                    })
                  : this.docs.forEach(function (t, n) {
                      e._addObject(t, n);
                    }),
                this.norm.clear());
            },
          },
          {
            key: "add",
            value: function (e) {
              var t = this.size();
              g(e) ? this._addString(e, t) : this._addObject(e, t);
            },
          },
          {
            key: "removeAt",
            value: function (e) {
              this.records.splice(e, 1);
              for (var t = e, n = this.size(); t < n; t += 1)
                this.records[t].i -= 1;
            },
          },
          {
            key: "getValueForItemAtKeyId",
            value: function (e, t) {
              return e[this._keysMap[t]];
            },
          },
          {
            key: "size",
            value: function () {
              return this.records.length;
            },
          },
          {
            key: "_addString",
            value: function (e, t) {
              if (k(e) && !M(e)) {
                var n = { v: e, i: t, n: this.norm.get(e) };
                this.records.push(n);
              }
            },
          },
          {
            key: "_addObject",
            value: function (e, t) {
              var n = this,
                r = { i: t, $: {} };
              this.keys.forEach(function (t, i) {
                var o = t.getFn ? t.getFn(e) : n.getFn(e, t.path);
                if (k(o))
                  if (v(o))
                    !(function () {
                      for (
                        var e = [], t = [{ nestedArrIndex: -1, value: o }];
                        t.length;

                      ) {
                        var c = t.pop(),
                          a = c.nestedArrIndex,
                          s = c.value;
                        if (k(s))
                          if (g(s) && !M(s)) {
                            var u = { v: s, i: a, n: n.norm.get(s) };
                            e.push(u);
                          } else
                            v(s) &&
                              s.forEach(function (e, n) {
                                t.push({ nestedArrIndex: n, value: e });
                              });
                      }
                      r.$[i] = e;
                    })();
                  else if (g(o) && !M(o)) {
                    var c = { v: o, n: n.norm.get(o) };
                    r.$[i] = c;
                  }
              }),
                this.records.push(r);
            },
          },
          {
            key: "toJSON",
            value: function () {
              return { keys: this.keys, records: this.records };
            },
          },
        ]),
        e
      );
    })();
    function F(e, t) {
      var n =
          arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
        r = n.getFn,
        i = void 0 === r ? I.getFn : r,
        o = n.fieldNormWeight,
        c = void 0 === o ? I.fieldNormWeight : o,
        a = new $({ getFn: i, fieldNormWeight: c });
      return a.setKeys(e.map(_)), a.setSources(t), a.create(), a;
    }
    function R(e) {
      var t =
          arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
        n = t.errors,
        r = void 0 === n ? 0 : n,
        i = t.currentLocation,
        o = void 0 === i ? 0 : i,
        c = t.expectedLocation,
        a = void 0 === c ? 0 : c,
        s = t.distance,
        u = void 0 === s ? I.distance : s,
        h = t.ignoreLocation,
        l = void 0 === h ? I.ignoreLocation : h,
        f = r / e.length;
      if (l) return f;
      var d = Math.abs(a - o);
      return u ? f + d / u : d ? 1 : f;
    }
    function N() {
      for (
        var e =
            arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [],
          t =
            arguments.length > 1 && void 0 !== arguments[1]
              ? arguments[1]
              : I.minMatchCharLength,
          n = [],
          r = -1,
          i = -1,
          o = 0,
          c = e.length;
        o < c;
        o += 1
      ) {
        var a = e[o];
        a && -1 === r
          ? (r = o)
          : a ||
            -1 === r ||
            ((i = o - 1) - r + 1 >= t && n.push([r, i]), (r = -1));
      }
      return e[o - 1] && o - r >= t && n.push([r, o - 1]), n;
    }
    var P = 32;
    function W(e) {
      for (var t = {}, n = 0, r = e.length; n < r; n += 1) {
        var i = e.charAt(n);
        t[i] = (t[i] || 0) | (1 << (r - n - 1));
      }
      return t;
    }
    var T = (function () {
        function e(t) {
          var n = this,
            i =
              arguments.length > 1 && void 0 !== arguments[1]
                ? arguments[1]
                : {},
            o = i.location,
            c = void 0 === o ? I.location : o,
            a = i.threshold,
            s = void 0 === a ? I.threshold : a,
            u = i.distance,
            h = void 0 === u ? I.distance : u,
            l = i.includeMatches,
            f = void 0 === l ? I.includeMatches : l,
            d = i.findAllMatches,
            v = void 0 === d ? I.findAllMatches : d,
            g = i.minMatchCharLength,
            y = void 0 === g ? I.minMatchCharLength : g,
            p = i.isCaseSensitive,
            m = void 0 === p ? I.isCaseSensitive : p,
            k = i.ignoreLocation,
            M = void 0 === k ? I.ignoreLocation : k;
          if (
            (r(this, e),
            (this.options = {
              location: c,
              threshold: s,
              distance: h,
              includeMatches: f,
              findAllMatches: v,
              minMatchCharLength: y,
              isCaseSensitive: m,
              ignoreLocation: M,
            }),
            (this.pattern = m ? t : t.toLowerCase()),
            (this.chunks = []),
            this.pattern.length)
          ) {
            var b = function (e, t) {
                n.chunks.push({ pattern: e, alphabet: W(e), startIndex: t });
              },
              x = this.pattern.length;
            if (x > P) {
              for (var w = 0, L = x % P, S = x - L; w < S; )
                b(this.pattern.substr(w, P), w), (w += P);
              if (L) {
                var _ = x - P;
                b(this.pattern.substr(_), _);
              }
            } else b(this.pattern, 0);
          }
        }
        return (
          o(e, [
            {
              key: "searchIn",
              value: function (e) {
                var t = this.options,
                  n = t.isCaseSensitive,
                  r = t.includeMatches;
                if ((n || (e = e.toLowerCase()), this.pattern === e)) {
                  var i = { isMatch: !0, score: 0 };
                  return r && (i.indices = [[0, e.length - 1]]), i;
                }
                var o = this.options,
                  c = o.location,
                  a = o.distance,
                  s = o.threshold,
                  u = o.findAllMatches,
                  h = o.minMatchCharLength,
                  l = o.ignoreLocation,
                  d = [],
                  v = 0,
                  g = !1;
                this.chunks.forEach(function (t) {
                  var n = t.pattern,
                    i = t.alphabet,
                    o = t.startIndex,
                    y = (function (e, t, n) {
                      var r =
                          arguments.length > 3 && void 0 !== arguments[3]
                            ? arguments[3]
                            : {},
                        i = r.location,
                        o = void 0 === i ? I.location : i,
                        c = r.distance,
                        a = void 0 === c ? I.distance : c,
                        s = r.threshold,
                        u = void 0 === s ? I.threshold : s,
                        h = r.findAllMatches,
                        l = void 0 === h ? I.findAllMatches : h,
                        f = r.minMatchCharLength,
                        d = void 0 === f ? I.minMatchCharLength : f,
                        v = r.includeMatches,
                        g = void 0 === v ? I.includeMatches : v,
                        y = r.ignoreLocation,
                        p = void 0 === y ? I.ignoreLocation : y;
                      if (t.length > P) throw new Error(w(P));
                      for (
                        var m,
                          k = t.length,
                          M = e.length,
                          b = Math.max(0, Math.min(o, M)),
                          x = u,
                          L = b,
                          S = d > 1 || g,
                          _ = S ? Array(M) : [];
                        (m = e.indexOf(t, L)) > -1;

                      ) {
                        var O = R(t, {
                          currentLocation: m,
                          expectedLocation: b,
                          distance: a,
                          ignoreLocation: p,
                        });
                        if (((x = Math.min(O, x)), (L = m + k), S))
                          for (var j = 0; j < k; ) (_[m + j] = 1), (j += 1);
                      }
                      L = -1;
                      for (
                        var A = [], C = 1, E = k + M, $ = 1 << (k - 1), F = 0;
                        F < k;
                        F += 1
                      ) {
                        for (var W = 0, T = E; W < T; )
                          R(t, {
                            errors: F,
                            currentLocation: b + T,
                            expectedLocation: b,
                            distance: a,
                            ignoreLocation: p,
                          }) <= x
                            ? (W = T)
                            : (E = T),
                            (T = Math.floor((E - W) / 2 + W));
                        E = T;
                        var z = Math.max(1, b - T + 1),
                          D = l ? M : Math.min(b + T, M) + k,
                          K = Array(D + 2);
                        K[D + 1] = (1 << F) - 1;
                        for (var q = D; q >= z; q -= 1) {
                          var B = q - 1,
                            J = n[e.charAt(B)];
                          if (
                            (S && (_[B] = +!!J),
                            (K[q] = ((K[q + 1] << 1) | 1) & J),
                            F &&
                              (K[q] |= ((A[q + 1] | A[q]) << 1) | 1 | A[q + 1]),
                            K[q] & $ &&
                              (C = R(t, {
                                errors: F,
                                currentLocation: B,
                                expectedLocation: b,
                                distance: a,
                                ignoreLocation: p,
                              })) <= x)
                          ) {
                            if (((x = C), (L = B) <= b)) break;
                            z = Math.max(1, 2 * b - L);
                          }
                        }
                        if (
                          R(t, {
                            errors: F + 1,
                            currentLocation: b,
                            expectedLocation: b,
                            distance: a,
                            ignoreLocation: p,
                          }) > x
                        )
                          break;
                        A = K;
                      }
                      var U = { isMatch: L >= 0, score: Math.max(0.001, C) };
                      if (S) {
                        var V = N(_, d);
                        V.length ? g && (U.indices = V) : (U.isMatch = !1);
                      }
                      return U;
                    })(e, n, i, {
                      location: c + o,
                      distance: a,
                      threshold: s,
                      findAllMatches: u,
                      minMatchCharLength: h,
                      includeMatches: r,
                      ignoreLocation: l,
                    }),
                    p = y.isMatch,
                    m = y.score,
                    k = y.indices;
                  p && (g = !0),
                    (v += m),
                    p && k && (d = [].concat(f(d), f(k)));
                });
                var y = { isMatch: g, score: g ? v / this.chunks.length : 1 };
                return g && r && (y.indices = d), y;
              },
            },
          ]),
          e
        );
      })(),
      z = (function () {
        function e(t) {
          r(this, e), (this.pattern = t);
        }
        return (
          o(
            e,
            [{ key: "search", value: function () {} }],
            [
              {
                key: "isMultiMatch",
                value: function (e) {
                  return D(e, this.multiRegex);
                },
              },
              {
                key: "isSingleMatch",
                value: function (e) {
                  return D(e, this.singleRegex);
                },
              },
            ]
          ),
          e
        );
      })();
    function D(e, t) {
      var n = e.match(t);
      return n ? n[1] : null;
    }
    var K = (function (e) {
        a(n, e);
        var t = l(n);
        function n(e) {
          return r(this, n), t.call(this, e);
        }
        return (
          o(
            n,
            [
              {
                key: "search",
                value: function (e) {
                  var t = e === this.pattern;
                  return {
                    isMatch: t,
                    score: t ? 0 : 1,
                    indices: [0, this.pattern.length - 1],
                  };
                },
              },
            ],
            [
              {
                key: "type",
                get: function () {
                  return "exact";
                },
              },
              {
                key: "multiRegex",
                get: function () {
                  return /^="(.*)"$/;
                },
              },
              {
                key: "singleRegex",
                get: function () {
                  return /^=(.*)$/;
                },
              },
            ]
          ),
          n
        );
      })(z),
      q = (function (e) {
        a(n, e);
        var t = l(n);
        function n(e) {
          return r(this, n), t.call(this, e);
        }
        return (
          o(
            n,
            [
              {
                key: "search",
                value: function (e) {
                  var t = -1 === e.indexOf(this.pattern);
                  return {
                    isMatch: t,
                    score: t ? 0 : 1,
                    indices: [0, e.length - 1],
                  };
                },
              },
            ],
            [
              {
                key: "type",
                get: function () {
                  return "inverse-exact";
                },
              },
              {
                key: "multiRegex",
                get: function () {
                  return /^!"(.*)"$/;
                },
              },
              {
                key: "singleRegex",
                get: function () {
                  return /^!(.*)$/;
                },
              },
            ]
          ),
          n
        );
      })(z),
      B = (function (e) {
        a(n, e);
        var t = l(n);
        function n(e) {
          return r(this, n), t.call(this, e);
        }
        return (
          o(
            n,
            [
              {
                key: "search",
                value: function (e) {
                  var t = e.startsWith(this.pattern);
                  return {
                    isMatch: t,
                    score: t ? 0 : 1,
                    indices: [0, this.pattern.length - 1],
                  };
                },
              },
            ],
            [
              {
                key: "type",
                get: function () {
                  return "prefix-exact";
                },
              },
              {
                key: "multiRegex",
                get: function () {
                  return /^\^"(.*)"$/;
                },
              },
              {
                key: "singleRegex",
                get: function () {
                  return /^\^(.*)$/;
                },
              },
            ]
          ),
          n
        );
      })(z),
      J = (function (e) {
        a(n, e);
        var t = l(n);
        function n(e) {
          return r(this, n), t.call(this, e);
        }
        return (
          o(
            n,
            [
              {
                key: "search",
                value: function (e) {
                  var t = !e.startsWith(this.pattern);
                  return {
                    isMatch: t,
                    score: t ? 0 : 1,
                    indices: [0, e.length - 1],
                  };
                },
              },
            ],
            [
              {
                key: "type",
                get: function () {
                  return "inverse-prefix-exact";
                },
              },
              {
                key: "multiRegex",
                get: function () {
                  return /^!\^"(.*)"$/;
                },
              },
              {
                key: "singleRegex",
                get: function () {
                  return /^!\^(.*)$/;
                },
              },
            ]
          ),
          n
        );
      })(z),
      U = (function (e) {
        a(n, e);
        var t = l(n);
        function n(e) {
          return r(this, n), t.call(this, e);
        }
        return (
          o(
            n,
            [
              {
                key: "search",
                value: function (e) {
                  var t = e.endsWith(this.pattern);
                  return {
                    isMatch: t,
                    score: t ? 0 : 1,
                    indices: [e.length - this.pattern.length, e.length - 1],
                  };
                },
              },
            ],
            [
              {
                key: "type",
                get: function () {
                  return "suffix-exact";
                },
              },
              {
                key: "multiRegex",
                get: function () {
                  return /^"(.*)"\$$/;
                },
              },
              {
                key: "singleRegex",
                get: function () {
                  return /^(.*)\$$/;
                },
              },
            ]
          ),
          n
        );
      })(z),
      V = (function (e) {
        a(n, e);
        var t = l(n);
        function n(e) {
          return r(this, n), t.call(this, e);
        }
        return (
          o(
            n,
            [
              {
                key: "search",
                value: function (e) {
                  var t = !e.endsWith(this.pattern);
                  return {
                    isMatch: t,
                    score: t ? 0 : 1,
                    indices: [0, e.length - 1],
                  };
                },
              },
            ],
            [
              {
                key: "type",
                get: function () {
                  return "inverse-suffix-exact";
                },
              },
              {
                key: "multiRegex",
                get: function () {
                  return /^!"(.*)"\$$/;
                },
              },
              {
                key: "singleRegex",
                get: function () {
                  return /^!(.*)\$$/;
                },
              },
            ]
          ),
          n
        );
      })(z),
      G = (function (e) {
        a(n, e);
        var t = l(n);
        function n(e) {
          var i,
            o =
              arguments.length > 1 && void 0 !== arguments[1]
                ? arguments[1]
                : {},
            c = o.location,
            a = void 0 === c ? I.location : c,
            s = o.threshold,
            u = void 0 === s ? I.threshold : s,
            h = o.distance,
            l = void 0 === h ? I.distance : h,
            f = o.includeMatches,
            d = void 0 === f ? I.includeMatches : f,
            v = o.findAllMatches,
            g = void 0 === v ? I.findAllMatches : v,
            y = o.minMatchCharLength,
            p = void 0 === y ? I.minMatchCharLength : y,
            m = o.isCaseSensitive,
            k = void 0 === m ? I.isCaseSensitive : m,
            M = o.ignoreLocation,
            b = void 0 === M ? I.ignoreLocation : M;
          return (
            r(this, n),
            ((i = t.call(this, e))._bitapSearch = new T(e, {
              location: a,
              threshold: u,
              distance: l,
              includeMatches: d,
              findAllMatches: g,
              minMatchCharLength: p,
              isCaseSensitive: k,
              ignoreLocation: b,
            })),
            i
          );
        }
        return (
          o(
            n,
            [
              {
                key: "search",
                value: function (e) {
                  return this._bitapSearch.searchIn(e);
                },
              },
            ],
            [
              {
                key: "type",
                get: function () {
                  return "fuzzy";
                },
              },
              {
                key: "multiRegex",
                get: function () {
                  return /^"(.*)"$/;
                },
              },
              {
                key: "singleRegex",
                get: function () {
                  return /^(.*)$/;
                },
              },
            ]
          ),
          n
        );
      })(z),
      H = (function (e) {
        a(n, e);
        var t = l(n);
        function n(e) {
          return r(this, n), t.call(this, e);
        }
        return (
          o(
            n,
            [
              {
                key: "search",
                value: function (e) {
                  for (
                    var t, n = 0, r = [], i = this.pattern.length;
                    (t = e.indexOf(this.pattern, n)) > -1;

                  )
                    (n = t + i), r.push([t, n - 1]);
                  var o = !!r.length;
                  return { isMatch: o, score: o ? 0 : 1, indices: r };
                },
              },
            ],
            [
              {
                key: "type",
                get: function () {
                  return "include";
                },
              },
              {
                key: "multiRegex",
                get: function () {
                  return /^'"(.*)"$/;
                },
              },
              {
                key: "singleRegex",
                get: function () {
                  return /^'(.*)$/;
                },
              },
            ]
          ),
          n
        );
      })(z),
      Q = [K, H, B, J, V, U, q, G],
      X = Q.length,
      Y = / +(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)/;
    function Z(e) {
      var t =
        arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {};
      return e.split("|").map(function (e) {
        for (
          var n = e
              .trim()
              .split(Y)
              .filter(function (e) {
                return e && !!e.trim();
              }),
            r = [],
            i = 0,
            o = n.length;
          i < o;
          i += 1
        ) {
          for (var c = n[i], a = !1, s = -1; !a && ++s < X; ) {
            var u = Q[s],
              h = u.isMultiMatch(c);
            h && (r.push(new u(h, t)), (a = !0));
          }
          if (!a)
            for (s = -1; ++s < X; ) {
              var l = Q[s],
                f = l.isSingleMatch(c);
              if (f) {
                r.push(new l(f, t));
                break;
              }
            }
        }
        return r;
      });
    }
    var ee = new Set([G.type, H.type]),
      te = (function () {
        function e(t) {
          var n =
              arguments.length > 1 && void 0 !== arguments[1]
                ? arguments[1]
                : {},
            i = n.isCaseSensitive,
            o = void 0 === i ? I.isCaseSensitive : i,
            c = n.includeMatches,
            a = void 0 === c ? I.includeMatches : c,
            s = n.minMatchCharLength,
            u = void 0 === s ? I.minMatchCharLength : s,
            h = n.ignoreLocation,
            l = void 0 === h ? I.ignoreLocation : h,
            f = n.findAllMatches,
            d = void 0 === f ? I.findAllMatches : f,
            v = n.location,
            g = void 0 === v ? I.location : v,
            y = n.threshold,
            p = void 0 === y ? I.threshold : y,
            m = n.distance,
            k = void 0 === m ? I.distance : m;
          r(this, e),
            (this.query = null),
            (this.options = {
              isCaseSensitive: o,
              includeMatches: a,
              minMatchCharLength: u,
              findAllMatches: d,
              ignoreLocation: l,
              location: g,
              threshold: p,
              distance: k,
            }),
            (this.pattern = o ? t : t.toLowerCase()),
            (this.query = Z(this.pattern, this.options));
        }
        return (
          o(
            e,
            [
              {
                key: "searchIn",
                value: function (e) {
                  var t = this.query;
                  if (!t) return { isMatch: !1, score: 1 };
                  var n = this.options,
                    r = n.includeMatches;
                  e = n.isCaseSensitive ? e : e.toLowerCase();
                  for (
                    var i = 0, o = [], c = 0, a = 0, s = t.length;
                    a < s;
                    a += 1
                  ) {
                    var u = t[a];
                    (o.length = 0), (i = 0);
                    for (var h = 0, l = u.length; h < l; h += 1) {
                      var d = u[h],
                        v = d.search(e),
                        g = v.isMatch,
                        y = v.indices,
                        p = v.score;
                      if (!g) {
                        (c = 0), (i = 0), (o.length = 0);
                        break;
                      }
                      if (((i += 1), (c += p), r)) {
                        var m = d.constructor.type;
                        ee.has(m) ? (o = [].concat(f(o), f(y))) : o.push(y);
                      }
                    }
                    if (i) {
                      var k = { isMatch: !0, score: c / i };
                      return r && (k.indices = o), k;
                    }
                  }
                  return { isMatch: !1, score: 1 };
                },
              },
            ],
            [
              {
                key: "condition",
                value: function (e, t) {
                  return t.useExtendedSearch;
                },
              },
            ]
          ),
          e
        );
      })(),
      ne = [];
    function re(e, t) {
      for (var n = 0, r = ne.length; n < r; n += 1) {
        var i = ne[n];
        if (i.condition(e, t)) return new i(e, t);
      }
      return new T(e, t);
    }
    var ie = "$and",
      oe = "$or",
      ce = "$path",
      ae = "$val",
      se = function (e) {
        return !(!e[ie] && !e[oe]);
      },
      ue = function (e) {
        return !!e[ce];
      },
      he = function (e) {
        return !v(e) && m(e) && !se(e);
      },
      le = function (e) {
        return c(
          {},
          ie,
          Object.keys(e).map(function (t) {
            return c({}, t, e[t]);
          })
        );
      };
    function fe(e, t) {
      var n = t.ignoreFieldNorm,
        r = void 0 === n ? I.ignoreFieldNorm : n;
      e.forEach(function (e) {
        var t = 1;
        e.matches.forEach(function (e) {
          var n = e.key,
            i = e.norm,
            o = e.score,
            c = n ? n.weight : null;
          t *= Math.pow(
            0 === o && c ? Number.EPSILON : o,
            (c || 1) * (r ? 1 : i)
          );
        }),
          (e.score = t);
      });
    }
    function de(e, t) {
      var n = e.matches;
      (t.matches = []),
        k(n) &&
          n.forEach(function (e) {
            if (k(e.indices) && e.indices.length) {
              var n = { indices: e.indices, value: e.value };
              e.key && (n.key = e.key.src),
                e.idx > -1 && (n.refIndex = e.idx),
                t.matches.push(n);
            }
          });
    }
    function ve(e, t) {
      t.score = e.score;
    }
    function ge(e, t) {
      var n =
          arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
        r = n.includeMatches,
        i = void 0 === r ? I.includeMatches : r,
        o = n.includeScore,
        c = void 0 === o ? I.includeScore : o,
        a = [];
      return (
        i && a.push(de),
        c && a.push(ve),
        e.map(function (e) {
          var n = e.idx,
            r = { item: t[n], refIndex: n };
          return (
            a.length &&
              a.forEach(function (t) {
                t(e, r);
              }),
            r
          );
        })
      );
    }
    var ye = (function () {
      function e(n) {
        var i =
            arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          o = arguments.length > 2 ? arguments[2] : void 0;
        r(this, e),
          (this.options = t(t({}, I), i)),
          this.options.useExtendedSearch,
          (this._keyStore = new S(this.options.keys)),
          this.setCollection(n, o);
      }
      return (
        o(e, [
          {
            key: "setCollection",
            value: function (e, t) {
              if (((this._docs = e), t && !(t instanceof $)))
                throw new Error("Incorrect 'index' type");
              this._myIndex =
                t ||
                F(this.options.keys, this._docs, {
                  getFn: this.options.getFn,
                  fieldNormWeight: this.options.fieldNormWeight,
                });
            },
          },
          {
            key: "add",
            value: function (e) {
              k(e) && (this._docs.push(e), this._myIndex.add(e));
            },
          },
          {
            key: "remove",
            value: function () {
              for (
                var e =
                    arguments.length > 0 && void 0 !== arguments[0]
                      ? arguments[0]
                      : function () {
                          return !1;
                        },
                  t = [],
                  n = 0,
                  r = this._docs.length;
                n < r;
                n += 1
              ) {
                var i = this._docs[n];
                e(i, n) && (this.removeAt(n), (n -= 1), (r -= 1), t.push(i));
              }
              return t;
            },
          },
          {
            key: "removeAt",
            value: function (e) {
              this._docs.splice(e, 1), this._myIndex.removeAt(e);
            },
          },
          {
            key: "getIndex",
            value: function () {
              return this._myIndex;
            },
          },
          {
            key: "search",
            value: function (e) {
              var t =
                  arguments.length > 1 && void 0 !== arguments[1]
                    ? arguments[1]
                    : {},
                n = t.limit,
                r = void 0 === n ? -1 : n,
                i = this.options,
                o = i.includeMatches,
                c = i.includeScore,
                a = i.shouldSort,
                s = i.sortFn,
                u = i.ignoreFieldNorm,
                h = g(e)
                  ? g(this._docs[0])
                    ? this._searchStringList(e)
                    : this._searchObjectList(e)
                  : this._searchLogical(e);
              return (
                fe(h, { ignoreFieldNorm: u }),
                a && h.sort(s),
                y(r) && r > -1 && (h = h.slice(0, r)),
                ge(h, this._docs, { includeMatches: o, includeScore: c })
              );
            },
          },
          {
            key: "_searchStringList",
            value: function (e) {
              var t = re(e, this.options),
                n = this._myIndex.records,
                r = [];
              return (
                n.forEach(function (e) {
                  var n = e.v,
                    i = e.i,
                    o = e.n;
                  if (k(n)) {
                    var c = t.searchIn(n),
                      a = c.isMatch,
                      s = c.score,
                      u = c.indices;
                    a &&
                      r.push({
                        item: n,
                        idx: i,
                        matches: [{ score: s, value: n, norm: o, indices: u }],
                      });
                  }
                }),
                r
              );
            },
          },
          {
            key: "_searchLogical",
            value: function (e) {
              var t = this,
                n = (function (e, t) {
                  var n = (
                      arguments.length > 2 && void 0 !== arguments[2]
                        ? arguments[2]
                        : {}
                    ).auto,
                    r = void 0 === n || n,
                    i = function e(n) {
                      var i = Object.keys(n),
                        o = ue(n);
                      if (!o && i.length > 1 && !se(n)) return e(le(n));
                      if (he(n)) {
                        var c = o ? n[ce] : i[0],
                          a = o ? n[ae] : n[c];
                        if (!g(a)) throw new Error(x(c));
                        var s = { keyId: j(c), pattern: a };
                        return r && (s.searcher = re(a, t)), s;
                      }
                      var u = { children: [], operator: i[0] };
                      return (
                        i.forEach(function (t) {
                          var r = n[t];
                          v(r) &&
                            r.forEach(function (t) {
                              u.children.push(e(t));
                            });
                        }),
                        u
                      );
                    };
                  return se(e) || (e = le(e)), i(e);
                })(e, this.options),
                r = function e(n, r, i) {
                  if (!n.children) {
                    var o = n.keyId,
                      c = n.searcher,
                      a = t._findMatches({
                        key: t._keyStore.get(o),
                        value: t._myIndex.getValueForItemAtKeyId(r, o),
                        searcher: c,
                      });
                    return a && a.length
                      ? [{ idx: i, item: r, matches: a }]
                      : [];
                  }
                  for (
                    var s = [], u = 0, h = n.children.length;
                    u < h;
                    u += 1
                  ) {
                    var l = e(n.children[u], r, i);
                    if (l.length) s.push.apply(s, f(l));
                    else if (n.operator === ie) return [];
                  }
                  return s;
                },
                i = this._myIndex.records,
                o = {},
                c = [];
              return (
                i.forEach(function (e) {
                  var t = e.$,
                    i = e.i;
                  if (k(t)) {
                    var a = r(n, t, i);
                    a.length &&
                      (o[i] ||
                        ((o[i] = { idx: i, item: t, matches: [] }),
                        c.push(o[i])),
                      a.forEach(function (e) {
                        var t,
                          n = e.matches;
                        (t = o[i].matches).push.apply(t, f(n));
                      }));
                  }
                }),
                c
              );
            },
          },
          {
            key: "_searchObjectList",
            value: function (e) {
              var t = this,
                n = re(e, this.options),
                r = this._myIndex,
                i = r.keys,
                o = r.records,
                c = [];
              return (
                o.forEach(function (e) {
                  var r = e.$,
                    o = e.i;
                  if (k(r)) {
                    var a = [];
                    i.forEach(function (e, i) {
                      a.push.apply(
                        a,
                        f(t._findMatches({ key: e, value: r[i], searcher: n }))
                      );
                    }),
                      a.length && c.push({ idx: o, item: r, matches: a });
                  }
                }),
                c
              );
            },
          },
          {
            key: "_findMatches",
            value: function (e) {
              var t = e.key,
                n = e.value,
                r = e.searcher;
              if (!k(n)) return [];
              var i = [];
              if (v(n))
                n.forEach(function (e) {
                  var n = e.v,
                    o = e.i,
                    c = e.n;
                  if (k(n)) {
                    var a = r.searchIn(n),
                      s = a.isMatch,
                      u = a.score,
                      h = a.indices;
                    s &&
                      i.push({
                        score: u,
                        key: t,
                        value: n,
                        idx: o,
                        norm: c,
                        indices: h,
                      });
                  }
                });
              else {
                var o = n.v,
                  c = n.n,
                  a = r.searchIn(o),
                  s = a.isMatch,
                  u = a.score,
                  h = a.indices;
                s &&
                  i.push({ score: u, key: t, value: o, norm: c, indices: h });
              }
              return i;
            },
          },
        ]),
        e
      );
    })();
    return (
      (ye.version = "6.6.2"),
      (ye.createIndex = F),
      (ye.parseIndex = function (e) {
        var t =
            arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
          n = t.getFn,
          r = void 0 === n ? I.getFn : n,
          i = t.fieldNormWeight,
          o = void 0 === i ? I.fieldNormWeight : i,
          c = e.keys,
          a = e.records,
          s = new $({ getFn: r, fieldNormWeight: o });
        return s.setKeys(c), s.setIndexRecords(a), s;
      }),
      (ye.config = I),
      (function () {
        ne.push.apply(ne, arguments);
      })(te),
      ye
    );
  }),
  "object" == typeof exports && "undefined" != typeof module
    ? (module.exports = t())
    : "function" == typeof define && define.amd
    ? define(t)
    : ((e = "undefined" != typeof globalThis ? globalThis : e || self).Fuse =
        t());
